import React, { useEffect } from 'react';
import { useOwner } from '../hooks/useOwner';
import { useContractBalance } from '../hooks/useBalance';
import { WithdrawButton } from '../components/WithdrawButton';
import { Lock, Wallet, ShieldAlert } from 'lucide-react';
import { useAccount } from 'wagmi';
import { useNavigate } from 'react-router-dom';

export const Admin: React.FC = () => {
  const { isOwner, ownerAddress } = useOwner();
  const { balance, refetchBalance } = useContractBalance();
  const { isConnected } = useAccount();
  const navigate = useNavigate();

  // Redirect if not connected (optional, but good UX)
  useEffect(() => {
     refetchBalance();
  }, [refetchBalance]);

  if (!isConnected) {
    return (
        <div className="flex flex-col items-center justify-center min-h-[50vh] text-center space-y-4">
            <ShieldAlert className="w-16 h-16 text-slate-600" />
            <h2 className="text-2xl font-bold text-white">Access Restricted</h2>
            <p className="text-slate-400">Please connect your wallet to verify ownership.</p>
        </div>
    );
  }

  if (!isOwner) {
    return (
      <div className="max-w-2xl mx-auto mt-12 p-8 bg-red-900/10 border border-red-900/50 rounded-2xl text-center">
        <Lock className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-red-400 mb-2">Unauthorized Access</h2>
        <p className="text-red-200/70 mb-6">
          This page is restricted to the contract owner only.
        </p>
        <button 
            onClick={() => navigate('/')}
            className="text-slate-300 hover:text-white underline underline-offset-4"
        >
            Return to Home
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-indigo-500/10 rounded-xl">
            <Lock className="w-8 h-8 text-indigo-400" />
        </div>
        <div>
            <h1 className="text-3xl font-bold text-white">Admin Dashboard</h1>
            <p className="text-slate-400 font-mono text-sm mt-1">Owner: {ownerAddress}</p>
        </div>
      </div>

      <div className="grid gap-8">
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-8">
          <div className="flex items-center gap-3 mb-6">
            <Wallet className="w-6 h-6 text-emerald-400" />
            <h2 className="text-xl font-bold text-white">Contract Balance</h2>
          </div>
          
          <div className="flex flex-col sm:flex-row items-baseline justify-between gap-6">
            <div>
              <div className="text-5xl font-mono font-bold text-white tracking-tighter">
                {Number(balance).toFixed(4)}
              </div>
              <p className="text-slate-500 mt-2 font-medium">Available ETH to withdraw</p>
            </div>
            
            <div className="w-full sm:w-auto">
                <WithdrawButton />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};