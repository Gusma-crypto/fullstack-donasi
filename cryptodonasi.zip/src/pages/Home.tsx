import React from 'react';
import { DonateForm } from '../components/DonateForm';
import { useDonasi } from '../hooks/useDonasi';
import { Activity, Globe } from 'lucide-react';

export const Home: React.FC = () => {
  const { totalDonasi } = useDonasi();

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="text-center mb-16 space-y-4">
        <h1 className="text-5xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400 pb-2">
          Decentralized Giving
        </h1>
        <p className="text-slate-400 text-lg max-w-2xl mx-auto">
          Support our cause directly through the Ethereum blockchain. Secure, transparent, and immutable.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-12 items-start">
        <div className="space-y-8">
          {/* Stats Card */}
          <div className="bg-slate-800/30 border border-slate-700 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-2 text-indigo-400">
              <Activity className="w-5 h-5" />
              <span className="font-semibold uppercase tracking-wider text-sm">Total Raised</span>
            </div>
            <div className="text-4xl font-bold text-white flex items-baseline gap-2">
              {Number(totalDonasi).toFixed(4)}
              <span className="text-lg text-slate-500 font-medium">ETH</span>
            </div>
          </div>

          <div className="bg-slate-800/30 border border-slate-700 rounded-2xl p-6">
             <div className="flex items-center gap-3 mb-4 text-emerald-400">
              <Globe className="w-5 h-5" />
              <span className="font-semibold uppercase tracking-wider text-sm">Transparency</span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed">
                All transactions are verifiable on the Sepolia network. Smart contract logic ensures funds are managed according to the protocol rules.
            </p>
          </div>
        </div>

        <DonateForm />
      </div>
    </div>
  );
};