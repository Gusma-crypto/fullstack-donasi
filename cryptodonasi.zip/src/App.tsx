import React from 'react';
import { Routes, Route, HashRouter, Link, useLocation } from 'react-router-dom';
import { Home } from './pages/Home';
import { Admin } from './pages/Admin';
import { ConnectWallet } from './components/ConnectWallet';
import { LayoutDashboard, Home as HomeIcon } from 'lucide-react';

const Navigation = () => {
  const location = useLocation();
  
  const isActive = (path: string) => {
    return location.pathname === path 
      ? "text-white bg-slate-800" 
      : "text-slate-400 hover:text-white hover:bg-slate-800/50";
  };

  return (
    <nav className="flex items-center gap-2">
      <Link 
        to="/" 
        className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${isActive('/')}`}
      >
        <HomeIcon className="w-4 h-4" />
        Home
      </Link>
      <Link 
        to="/admin" 
        className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${isActive('/admin')}`}
      >
        <LayoutDashboard className="w-4 h-4" />
        Admin
      </Link>
    </nav>
  );
};

const App: React.FC = () => {
  return (
    <HashRouter>
      <div className="min-h-screen flex flex-col">
        {/* Header */}
        <header className="border-b border-slate-800 bg-slate-950/50 backdrop-blur-md sticky top-0 z-50">
          <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
            <div className="flex items-center gap-8">
              <Link to="/" className="flex items-center gap-2">
                <div className="w-8 h-8 bg-gradient-to-tr from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center font-bold text-white text-lg">
                  D
                </div>
                <span className="font-bold text-white text-lg hidden sm:block">CryptoDonasi</span>
              </Link>
              
              <Navigation />
            </div>

            <ConnectWallet />
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/admin" element={<Admin />} />
          </Routes>
        </main>

        {/* Footer */}
        <footer className="border-t border-slate-800 py-8 mt-12 bg-slate-950">
          <div className="max-w-6xl mx-auto px-4 text-center text-slate-500 text-sm">
            <p>&copy; {new Date().getFullYear()} CryptoDonasi Decentralized Platform.</p>
            <p className="mt-2 text-xs opacity-60">Running on Sepolia Testnet</p>
          </div>
        </footer>
      </div>
    </HashRouter>
  );
};

export default App;