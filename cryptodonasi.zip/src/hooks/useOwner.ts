import { useReadContract, useWriteContract, useWaitForTransactionReceipt, useAccount } from 'wagmi';
import { donasiContractConfig } from '../config/contracts';

export const useOwner = () => {
  const { address: userAddress } = useAccount();
  const { data: hash, writeContract, isPending, error: writeError } = useWriteContract();

  const { data: ownerAddress } = useReadContract({
    ...donasiContractConfig,
    functionName: 'owner',
  });

  const { isLoading: isConfirming, isSuccess: isConfirmed } = useWaitForTransactionReceipt({
    hash,
  });

  const isOwner = userAddress && ownerAddress && userAddress.toLowerCase() === (ownerAddress as string).toLowerCase();

  const withdrawFunds = () => {
    writeContract({
      ...donasiContractConfig,
      functionName: 'tarikDonasi',
    });
  };

  return {
    ownerAddress: ownerAddress as string,
    isOwner,
    withdrawFunds,
    isPending,
    isConfirming,
    isConfirmed,
    hash,
    writeError
  };
};