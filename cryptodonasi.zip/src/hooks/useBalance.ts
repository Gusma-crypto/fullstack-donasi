import { useReadContract } from 'wagmi';
import { formatEther } from 'viem';
import { donasiContractConfig } from '../config/contracts';

export const useContractBalance = () => {
  const { data: balanceWei, isLoading, isError, refetch: refetchBalance } = useReadContract({
    ...donasiContractConfig,
    functionName: 'getBalance',
  });

  return {
    balance: balanceWei ? formatEther(balanceWei as bigint) : '0',
    isLoading,
    isError,
    refetchBalance
  };
};