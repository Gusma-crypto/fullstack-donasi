import { useReadContract, useWriteContract, useWaitForTransactionReceipt } from 'wagmi';
import { parseEther, formatEther } from 'viem';
import { donasiContractConfig } from '../config/contracts';

export const useDonasi = () => {
  const { data: hash, writeContract, isPending, error: writeError } = useWriteContract();

  // Read Total Donasi (Note: Contract has a typo 'tototalDonasi')
  const { data: totalDonasiWei, refetch: refetchTotal } = useReadContract({
    ...donasiContractConfig,
    functionName: 'tototalDonasi',
  });

  const { isLoading: isConfirming, isSuccess: isConfirmed } = useWaitForTransactionReceipt({
    hash,
  });

  const sendDonation = (amount: string) => {
    try {
      writeContract({
        ...donasiContractConfig,
        functionName: 'donasi',
        value: parseEther(amount),
      });
    } catch (error) {
      console.error("Donation failed:", error);
    }
  };

  return {
    totalDonasi: totalDonasiWei ? formatEther(totalDonasiWei as bigint) : '0',
    sendDonation,
    isPending,
    isConfirming,
    isConfirmed,
    hash,
    writeError,
    refetchTotal,
  };
};