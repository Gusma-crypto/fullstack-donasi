import React, { useState, useEffect } from 'react';
import { useDonasi } from '../hooks/useDonasi';
import { Heart, Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { useAccount } from 'wagmi';

export const DonateForm: React.FC = () => {
  const [amount, setAmount] = useState('');
  const { sendDonation, isPending, isConfirming, isConfirmed, writeError } = useDonasi();
  const { isConnected } = useAccount();

  useEffect(() => {
    if (isConfirmed) {
      setAmount('');
    }
  }, [isConfirmed]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || parseFloat(amount) <= 0) return;
    sendDonation(amount);
  };

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-2xl p-6 shadow-xl">
      <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
        <Heart className="text-pink-500 fill-pink-500" />
        Make a Donation
      </h3>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="amount" className="block text-sm font-medium text-slate-400 mb-1">
            Amount (ETH)
          </label>
          <div className="relative">
            <input
              type="number"
              id="amount"
              step="0.001"
              min="0"
              placeholder="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              disabled={!isConnected || isPending || isConfirming}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            />
            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 font-bold">
              ETH
            </span>
          </div>
        </div>

        {writeError && (
          <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm flex items-start gap-2">
            <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
            <span>{writeError.message.split('\n')[0]}</span>
          </div>
        )}

        {isConfirmed && (
          <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-lg text-green-400 text-sm flex items-center gap-2">
            <CheckCircle className="w-4 h-4" />
            <span>Thank you! Donation successful.</span>
          </div>
        )}

        <button
          type="submit"
          disabled={!isConnected || !amount || isPending || isConfirming}
          className="w-full bg-gradient-to-r from-pink-500 to-violet-600 hover:from-pink-600 hover:to-violet-700 text-white font-bold py-3 px-4 rounded-xl shadow-lg shadow-purple-500/20 disabled:opacity-50 disabled:cursor-not-allowed flex justify-center items-center gap-2 transition-all transform hover:scale-[1.02] active:scale-[0.98]"
        >
          {isPending || isConfirming ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              Donate Now
            </>
          )}
        </button>

        {!isConnected && (
          <p className="text-center text-sm text-slate-500 mt-2">
            Please connect your wallet to donate.
          </p>
        )}
      </form>
    </div>
  );
};