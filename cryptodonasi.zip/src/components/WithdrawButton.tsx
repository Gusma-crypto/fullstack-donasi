import React from 'react';
import { useOwner } from '../hooks/useOwner';
import { Download, Loader2, ShieldCheck, AlertTriangle } from 'lucide-react';

export const WithdrawButton: React.FC = () => {
  const { withdrawFunds, isPending, isConfirming, isConfirmed, writeError } = useOwner();

  return (
    <div className="space-y-4">
      <button
        onClick={withdrawFunds}
        disabled={isPending || isConfirming}
        className="w-full sm:w-auto flex items-center justify-center gap-2 bg-orange-600 hover:bg-orange-700 text-white px-6 py-3 rounded-xl font-bold transition-all shadow-lg shadow-orange-600/20 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isPending || isConfirming ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            Withdrawing...
          </>
        ) : (
          <>
            <Download className="w-5 h-5" />
            Withdraw All Funds
          </>
        )}
      </button>

      {writeError && (
        <div className="p-4 bg-red-900/20 border border-red-800 rounded-xl flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-500 shrink-0" />
            <div className="text-sm text-red-200">
                <p className="font-bold">Transaction Failed</p>
                <p className="opacity-80">{writeError.message.slice(0, 100)}...</p>
            </div>
        </div>
      )}

      {isConfirmed && (
        <div className="p-4 bg-green-900/20 border border-green-800 rounded-xl flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-green-500" />
            <p className="text-sm text-green-200">Funds withdrawn successfully to owner address.</p>
        </div>
      )}
    </div>
  );
};