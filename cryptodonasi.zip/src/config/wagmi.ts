import { http, createConfig } from 'wagmi';
import { activeChain } from './chains';
import { injected } from 'wagmi/connectors';

export const config = createConfig({
  chains: [activeChain],
  connectors: [
    injected(),
  ],
  transports: {
    [activeChain.id]: http(),
  },
});