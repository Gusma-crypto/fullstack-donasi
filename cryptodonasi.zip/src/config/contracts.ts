import DonasiABI from '../abi/Donasi.json';

// Contract Address on Sepolia
export const DONASI_CONTRACT_ADDRESS = '0xcA8c44c9146670565A052F22f4bf63b19890CA39' as const;

export const donasiContractConfig = {
  address: DONASI_CONTRACT_ADDRESS,
  abi: DonasiABI,
} as const;