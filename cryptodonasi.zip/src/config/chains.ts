import { sepolia } from 'wagmi/chains';

export const activeChain = sepolia;